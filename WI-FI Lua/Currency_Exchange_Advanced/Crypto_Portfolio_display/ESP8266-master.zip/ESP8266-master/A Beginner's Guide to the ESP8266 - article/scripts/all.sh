./HTML-raw-to-full.sh
./createIndex.sh
./exportPDF.sh