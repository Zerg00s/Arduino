setTimeout(function() {
    let jsParagraph = document.createElement("p");
    jsParagraph.textContent = "You can even use folders.";
    document.body.appendChild(jsParagraph);
}, 2000);